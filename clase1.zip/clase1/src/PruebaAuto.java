/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Victoria
 */
public class PruebaAuto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Auto a = new Auto();
        //Patente 100 Dueño Victoria
        a.setPatente(100);
        a.setDueño("Victoria");
        System.out.println("La patente es: " + a.getPatente());
        System.out.println("Representacion del auto "+ a.toString());
    }
    
}
