
import PaqueteLectura.Lector;

/*
Modifique el ejercicio 2 para almacenar en la estructura
de datos el auto que ocupa cada plaza.
 */

/**
 *
 * @author Victoria
 */
public class Ej03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i,j;
        //DECLARAR LA MATRIZ
        int DIMF=5, DIMC=10;
        Auto [][] matriz = new Auto[DIMF][DIMC];
        for(i=0; i<DIMF;i++)
            for(j=0; j<DIMC; j++)
                matriz[i][j]=null;
        
     //   GeneradorAleatorio.iniciar();
     //   int patente = GeneradorAleatorio.generarInt(11);
         System.out.println("Ingrese la patente");
         int patente = Lector.leerInt();
        
        while (patente!=0){
            if ((patente % 2) == 0){
                System.out.println("Si pase: " + patente);
                
                System.out.println("Ingrese el dueño");
                String dueño = Lector.leerString();
                
                //Instanciar el objeto auto y cargarle valores
                Auto a = new Auto();
                a.setPatente(patente);
                a.setDueño(dueño);
                
                System.out.println("Ingrese piso (1..5) y plaza (1..10)");
                int piso = Lector.leerInt(); //asumo que es válido (1..5)
                int plaza = Lector.leerInt(); //asumo que es válido (1..10)
                
                matriz[piso-1][plaza-1]=a; //Cargo el objeto en la matriz
            }
            else{
                System.out.println("No pase: " + patente);
            }
            //patente = GeneradorAleatorio.generarInt(11);
            
            System.out.println("Ingrese la patente");
            patente = Lector.leerInt();
        }
        
        
        // informar para cada número de piso y número de plaza ocupado,
        // la representación del auto que la ocupa.  
        
        for(i=0;i<DIMF;i++){
            for(j=0; j<DIMC;j++){
               if (matriz[i][j]!=null)
                  System.out.println("Piso "+(i+1) + " Plaza: "+ (j+1) + 
                          matriz[i][j].toString());
           }
        }
        
        
        
        
    
    }
    
}
