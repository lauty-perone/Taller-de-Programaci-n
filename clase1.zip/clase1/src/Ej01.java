
import PaqueteLectura.GeneradorAleatorio;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *

1- Realice un programa que genere aleatoriamente números (patentes) hasta el 0. 
* Por cada una debe informar en consola si el auto tiene o no permitido el paso 
* (solo pasan los autos con patentes de números pares).


 */
public class Ej01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GeneradorAleatorio.iniciar();
        int patente = GeneradorAleatorio.generarInt(11);
        while (patente!=0){
            if ((patente % 2) == 0){
                System.out.println("Si pase: " + patente);
            }
            else{
                System.out.println("No pase: " + patente);
            }
            patente = GeneradorAleatorio.generarInt(11);
        }
    }
    
}
