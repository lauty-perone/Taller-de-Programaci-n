
import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;

/*
2- a) Realice un nuevo programa considerando que ahora el estacionamiento 
está dividido en 5 pisos y cada piso tiene 10 plazas. 
Por cada patente generada, debe ingresar por teclado el número de piso 
y número de plaza donde debe estacionar el auto, 
debiendo marcar ese lugar como ocupado en una estructura de datos adecuada. 

Nota: considere que el lugar ingresado (número de piso, número de plaza) 
está desocupado y dichos números son válidos.

     b) Informe cuál es el piso más ocupado.

 */

/**
 *
 * @author Victoria
 */
public class Ej02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i,j;
        //DECLARAR LA MATRIZ
        int DIMF=5, DIMC=10;
        boolean [][] matriz = new boolean[DIMF][DIMC];
        for(i=0; i<DIMF;i++)
            for(j=0; j<DIMC; j++)
                matriz[i][j]=false;
        
     //   GeneradorAleatorio.iniciar();
     //   int patente = GeneradorAleatorio.generarInt(11);
         System.out.println("Ingrese la patente");
         int patente = Lector.leerInt();
        while (patente!=0){
            if ((patente % 2) == 0){
                System.out.println("Si pase: " + patente);
                
                System.out.println("Ingrese piso (1..5) y plaza (1..10)");
                int piso = Lector.leerInt(); //asumo que es válido (1..5)
                int plaza = Lector.leerInt(); //asumo que es válido (1..10)
                
                matriz[piso-1][plaza-1]=true;
            }
            else{
                System.out.println("No pase: " + patente);
            }
            //patente = GeneradorAleatorio.generarInt(11);
            
            System.out.println("Ingrese la patente");
            patente = Lector.leerInt();
        }
        
        
        // Informe cuál es el piso más ocupado.
        int max=-1;
        int pisomax=0;
        
        for(i=0;i<DIMF;i++){
           //Calcular la cant. de plazas ocupadas en el piso i (total)
           int total=0; 
           for(j=0; j<DIMC;j++){
               if (matriz[i][j]) total++;
           }
           //Actualizar max
           if (total > max){
             max= total; 
             pisomax=i;
           }
        }
        
        System.out.println("El piso mas ocupado es " + (pisomax + 1));
        
    }
    
}
