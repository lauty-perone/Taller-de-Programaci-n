/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema1;


public class Ej04Matrices {

    public static void main(String[] args) {
     
    //1. definir la matriz de enteros de tamaño 10x10 e iniciarla con números aleatorios entre 0 y 200 
    
    //2. mostrar el contenido de la matriz en consola
    
    //3. calcular e informar la suma de todos los elementos almacenados entre las filas 2 y 9 y las columnas 0 y 3
    
    //4. generar un vector de 10 posiciones donde cada posición i contiene la suma de la columna i de la matriz 

    //5. lea un valor entero e indique si se encuentra o no en la matriz. En caso de encontrarse indique su ubicación (fila y columna)
    //   y en caso contrario imprima "No se encontró el elemento".

    }
}
