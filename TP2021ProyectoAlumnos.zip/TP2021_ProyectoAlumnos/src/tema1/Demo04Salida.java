/*
 Muestra Hola Mundo en consola.

 */

package tema1;

/**
 *
 * @author vsanz
 */
public class Demo04Salida {

   public static void main(String[] args) {
        System.out.print("Hola Mundo! "); 
        System.out.println("Hola Mundo! "); 
        System.out.println(1234);
        System.out.println(true);
        int año=2016;
        System.out.println ("Hola Mundo " + año + "!");

   }
}


